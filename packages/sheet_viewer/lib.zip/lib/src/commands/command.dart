abstract class Command {
  const Command();

  /// Execute the command.
  void execute();

  /// Restore the previous state.
  void undo();
}