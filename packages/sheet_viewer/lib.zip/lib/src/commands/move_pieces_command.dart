import '../controllers/sheet_viewer_controller.dart';
import '../models/layout_piece.dart';
import 'command.dart';

class MovePiecesCommand extends Command {
  MovePiecesCommand({
    required SheetViewerController controller,
    required Iterable<LayoutPiece> before,
    required Iterable<LayoutPiece> after,
  })  : _controller = controller,
        _before = List.unmodifiable(before),
        _after = List.unmodifiable(after);

  final SheetViewerController _controller;

  /// Pieces before the move.
  final List<LayoutPiece> _before;

  /// Pieces after the move.
  final List<LayoutPiece> _after;

  @override
  void execute() {
    _controller.updatePieces(_after);
  }

  @override
  void undo() {
    _controller.updatePieces(_before);
  }
}