import 'command.dart';

class CommandHistory {
  final List<Command> _undoStack = [];
  final List<Command> _redoStack = [];

  bool get canUndo => _undoStack.isNotEmpty;

  bool get canRedo => _redoStack.isNotEmpty;

  void execute(Command command) {
    command.execute();

    _undoStack.add(command);
    _redoStack.clear();
  }

  /// Adds a command that has already been applied.
  void push(Command command) {
    _undoStack.add(command);
    _redoStack.clear();
  }

  void undo() {
    if (!canUndo) return;

    final command = _undoStack.removeLast();

    command.undo();

    _redoStack.add(command);
  }

  void redo() {
    if (!canRedo) return;

    final command = _redoStack.removeLast();

    command.execute();

    _undoStack.add(command);
  }

  void clear() {
    _undoStack.clear();
    _redoStack.clear();
  }
}