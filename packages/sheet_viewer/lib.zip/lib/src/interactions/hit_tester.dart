import 'package:flutter/material.dart';

import '../controllers/selection_controller.dart';
import '../models/layout_piece.dart';
import '../models/sheet_model.dart';
import 'hit_test_result.dart';
import 'resize_handle.dart';

class HitTester {
  const HitTester();

  static const double handleRadius = 8;

  //--------------------------------------------------------------------------
  // Single point hit testing
  //--------------------------------------------------------------------------

  HitTestResult? hitTest({
    required Offset worldPosition,
    required SheetModel sheet,
    required SelectionController selection,
  }) {
    // Iterate in reverse so the top-most piece wins.
    for (final LayoutPiece piece in sheet.pieces.reversed) {
      final rect = Rect.fromLTWH(
        piece.bounds.x,
        piece.bounds.y,
        piece.bounds.width,
        piece.bounds.height,
      );

      // Selected pieces expose resize handles.
      if (selection.isSelected(piece.id)) {
        final handle = _hitResizeHandle(worldPosition, rect);

        if (handle != ResizeHandle.none) {
          return HitTestResult(
            piece: piece,
            handle: handle,
          );
        }
      }

      if (rect.contains(worldPosition)) {
        return HitTestResult(piece: piece);
      }
    }

    return null;
  }

  //--------------------------------------------------------------------------
  // Rectangle hit testing (used for marquee selection)
  //--------------------------------------------------------------------------

  List<LayoutPiece> hitTestRect({
    required Rect worldRect,
    required SheetModel sheet,
    bool fullyContained = false,
  }) {
    final result = <LayoutPiece>[];

    for (final piece in sheet.pieces) {
      final rect = Rect.fromLTWH(
        piece.bounds.x,
        piece.bounds.y,
        piece.bounds.width,
        piece.bounds.height,
      );

      final hit = fullyContained
          ? worldRect.contains(rect.topLeft) &&
          worldRect.contains(rect.bottomRight)
          : worldRect.overlaps(rect);

      if (hit) {
        result.add(piece);
      }
    }

    return result;
  }

  //--------------------------------------------------------------------------
  // Resize handles
  //--------------------------------------------------------------------------

  ResizeHandle _hitResizeHandle(
      Offset point,
      Rect rect,
      ) {
    if (_contains(point, rect.topLeft)) {
      return ResizeHandle.topLeft;
    }

    if (_contains(point, rect.topCenter)) {
      return ResizeHandle.top;
    }

    if (_contains(point, rect.topRight)) {
      return ResizeHandle.topRight;
    }

    if (_contains(point, rect.centerLeft)) {
      return ResizeHandle.left;
    }

    if (_contains(point, rect.centerRight)) {
      return ResizeHandle.right;
    }

    if (_contains(point, rect.bottomLeft)) {
      return ResizeHandle.bottomLeft;
    }

    if (_contains(point, rect.bottomCenter)) {
      return ResizeHandle.bottom;
    }

    if (_contains(point, rect.bottomRight)) {
      return ResizeHandle.bottomRight;
    }

    return ResizeHandle.none;
  }

  bool _contains(
      Offset point,
      Offset center,
      ) {
    return (point - center).distance <= handleRadius;
  }
}