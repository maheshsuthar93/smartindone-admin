import 'package:flutter/material.dart';
import 'package:sheet_viewer/src/interactions/snap_engine.dart';

import '../../sheet_viewer.dart';
import '../controllers/sheet_viewer_controller.dart';
import '../models/piece_bounds.dart';
import 'hit_tester.dart';
import 'interaction_mode.dart';
import 'piece_resizer.dart';
import 'resize_handle.dart';
import '../commands/move_pieces_command.dart';
import '../models/layout_piece.dart';

class InteractionManager {
  InteractionManager({required this.controller});

  final SheetViewerController controller;

  final HitTester _hitTester = const HitTester();

  InteractionMode _mode = InteractionMode.idle;

  String? _activePieceId;

  Offset? _startWorld;

  PieceBounds? _startBounds;

  ResizeHandle _resizeHandle = ResizeHandle.none;

  /// Starting bounds of every piece participating in the current drag.
  final Map<String, PieceBounds> _dragStartBounds = {};
  final Map<String, LayoutPiece> _dragStartPieces = {};

  InteractionMode get mode => _mode;

  bool get isDragging => _mode == InteractionMode.dragging;

  bool get isResizing => _mode == InteractionMode.resizing;

  bool get isPanning => _mode == InteractionMode.panning;

  //--------------------------------------------------------------------------
  // Hover
  //--------------------------------------------------------------------------

  void hover(Offset screenPosition) {
    final world = controller.camera.screenToWorld(screenPosition);

    final result = _hitTester.hitTest(
      worldPosition: world,
      sheet: controller.sheet,
      selection: controller.selection,
    );

    controller.selection.setHovered(result?.piece);
  }

  //--------------------------------------------------------------------------
  // Tap Selection
  //--------------------------------------------------------------------------

  void tap(Offset screenPosition) {
    final world = controller.camera.screenToWorld(screenPosition);

    final result = _hitTester.hitTest(
      worldPosition: world,
      sheet: controller.sheet,
      selection: controller.selection,
    );

    if (result == null) {
      controller.selection.clear();
      return;
    }

    controller.selection.select(result.piece.id);
  }

  //--------------------------------------------------------------------------
  // Pointer Down
  //--------------------------------------------------------------------------

  void startDrag(Offset screenPosition) {
    final world = controller.camera.screenToWorld(screenPosition);

    final result = _hitTester.hitTest(
      worldPosition: world,
      sheet: controller.sheet,
      selection: controller.selection,
    );

    _dragStartBounds.clear();
    _dragStartPieces.clear();

    // Empty space -> Marquee Selection
    if (result == null) {
      _mode = InteractionMode.marqueeSelecting;

      _activePieceId = null;
      _startWorld = world;
      _startBounds = null;
      _resizeHandle = ResizeHandle.none;

      controller.selection.startMarquee(world);

      return;
    }

    final piece = result.piece;

    // If the clicked piece isn't already selected,
    // make it the only selected piece.
    if (!controller.selection.isSelected(piece.id)) {
      controller.selection.select(piece.id);
    }

    _activePieceId = piece.id;
    _startWorld = world;
    _startBounds = piece.bounds;

    for (final id in controller.selection.selectedIds) {
      final selectedPiece = controller.pieceById(id);

      if (selectedPiece == null) {
        continue;
      }

      _dragStartBounds[id] = selectedPiece.bounds;
      _dragStartPieces[id] = selectedPiece;
    }

    // Resize
    if (result.isResize) {
      _mode = InteractionMode.resizing;
      _resizeHandle = result.handle;
      return;
    }

    // Drag
    _mode = InteractionMode.dragging;
    _resizeHandle = ResizeHandle.none;

    controller.selection.startDragging(piece.id);
  }

  //--------------------------------------------------------------------------
  // Update
  //--------------------------------------------------------------------------

  void updateDrag(Offset screenPosition) {
    switch (_mode) {
      case InteractionMode.dragging:
        _updatePieceDrag(screenPosition);
        break;

      case InteractionMode.resizing:
        _updateResize(screenPosition);
        break;

      case InteractionMode.marqueeSelecting:
        _updateMarquee(screenPosition);
        break;

      case InteractionMode.panning:
        break;

      case InteractionMode.idle:
        break;
    }
  }

  void _updateMarquee(Offset screenPosition) {
    if (_startWorld == null) {
      return;
    }

    final world = controller.camera.screenToWorld(screenPosition);

    controller.selection.updateMarquee(_startWorld!, world);

    final rect = Rect.fromPoints(_startWorld!, world);

    final selected = <String>[];

    for (final piece in controller.pieces) {
      final pieceRect = Rect.fromLTWH(
        piece.bounds.x,
        piece.bounds.y,
        piece.bounds.width,
        piece.bounds.height,
      );

      if (rect.overlaps(pieceRect)) {
        selected.add(piece.id);
      }
    }

    controller.selection.selectAll(selected);
  }

  //--------------------------------------------------------------------------
  // End
  //--------------------------------------------------------------------------

  void endDrag() {
    if (_mode == InteractionMode.marqueeSelecting) {
      controller.selection.finishMarquee();
    }

    if (_mode == InteractionMode.dragging) {
      controller.selection.stopDragging();

      final before = <LayoutPiece>[];
      final after = <LayoutPiece>[];

      for (final entry in _dragStartPieces.entries) {
        final current = controller.pieceById(entry.key);

        if (current == null) {
          continue;
        }

        before.add(entry.value);
        after.add(current);
      }

      bool changed = false;

      for (var i = 0; i < before.length; i++) {
        if (before[i].bounds != after[i].bounds) {
          changed = true;
          break;
        }
      }

      if (changed) {
        controller.pushCommand(
          MovePiecesCommand(
            controller: controller,
            before: before,
            after: after,
          ),
        );
      }
    }

    _mode = InteractionMode.idle;

    _activePieceId = null;
    _startWorld = null;
    _startBounds = null;
    _resizeHandle = ResizeHandle.none;

    _dragStartBounds.clear();
    _dragStartPieces.clear();
  }

  //--------------------------------------------------------------------------
  // Cancel
  //--------------------------------------------------------------------------

  void cancel() {
    endDrag();
    controller.selection.clear();
  }

  //--------------------------------------------------------------------------
  // Resize
  //--------------------------------------------------------------------------

  void _updateResize(Offset screenPosition) {
    if (_activePieceId == null || _startWorld == null || _startBounds == null) {
      return;
    }

    final piece = controller.pieceById(_activePieceId!);

    if (piece == null) {
      return;
    }

    final world = controller.camera.screenToWorld(screenPosition);

    final delta = world - _startWorld!;

    final bounds = PieceResizer.resize(
      original: _startBounds!,
      handle: _resizeHandle,
      delta: delta,
      sheetSize: Size(controller.sheet.width, controller.sheet.height),
    );

    final snapped = SnapEngine.snap(bounds);

    controller.updatePiece(piece.copyWith(bounds: snapped));
  }

  //------------------------------------------------------------------------------
  // Multi-piece Drag
  //------------------------------------------------------------------------------

  void _updatePieceDrag(Offset screenPosition) {
    if (_startWorld == null || _dragStartBounds.isEmpty) {
      return;
    }

    final world = controller.camera.screenToWorld(screenPosition);
    final delta = world - _startWorld!;

    final updatedPieces = <LayoutPiece>[];

    for (final entry in _dragStartBounds.entries) {
      final piece = controller.pieceById(entry.key);

      if (piece == null) {
        continue;
      }

      final start = entry.value;

      double x = start.x + delta.dx;
      double y = start.y + delta.dy;

      x = x.clamp(0.0, controller.sheet.width - start.width);

      y = y.clamp(0.0, controller.sheet.height - start.height);

      final snapped = SnapEngine.snap(start.copyWith(x: x, y: y));

      updatedPieces.add(piece.copyWith(bounds: snapped));
    }

    controller.updatePieces(updatedPieces);
  }
}
