import '../models/layout_piece.dart';

/// Result of a hit test.
import '../models/layout_piece.dart';
import 'resize_handle.dart';

final class HitTestResult {
  const HitTestResult({
    required this.piece,
    this.handle = ResizeHandle.none,
  });

  final LayoutPiece piece;

  final ResizeHandle handle;

  bool get isResize => handle != ResizeHandle.none;
}