import 'package:flutter/foundation.dart';

import 'edge_band.dart';
import 'piece_bounds.dart';
import 'grain_direction.dart';
import 'piece_status.dart';

@immutable
final class LayoutPiece {
  const LayoutPiece({
    required this.id,
    required this.label,
    required this.bounds,
    this.status = PieceStatus.pending,
    this.grainDirection = GrainDirection.none,
    this.edgeBands = const {},
    this.rotation = 0,
  });

  final String id;

  final String label;

  final PieceBounds bounds;

  final PieceStatus status;

  final GrainDirection grainDirection;

  final Set<EdgeBand> edgeBands;

  /// 0 / 90 / 180 / 270
  final int rotation;

  LayoutPiece copyWith({
    String? id,
    String? label,
    PieceBounds? bounds,
    PieceStatus? status,
    GrainDirection? grainDirection,
    Set<EdgeBand>? edgeBands,
    bool? selected,
    int? rotation,
  }) {
    return LayoutPiece(
      id: id ?? this.id,
      label: label ?? this.label,
      bounds: bounds ?? this.bounds,
      status: status ?? this.status,
      grainDirection: grainDirection ?? this.grainDirection,
      edgeBands: edgeBands ?? this.edgeBands,
      rotation: rotation ?? this.rotation,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
          other is LayoutPiece && id == other.id;

  @override
  int get hashCode => id.hashCode;
}