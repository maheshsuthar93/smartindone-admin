enum PieceStatus {
  pending,
  inProgress,
  completed,
  rejected,
}