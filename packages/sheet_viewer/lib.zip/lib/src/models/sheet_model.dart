import 'package:flutter/foundation.dart';

import 'layout_piece.dart';

@immutable
final class SheetModel {
  const SheetModel({
    required this.id,
    required this.width,
    required this.height,
    this.pieces = const [],
  });

  final String id;

  /// millimeters
  final double width;

  /// millimeters
  final double height;

  final List<LayoutPiece> pieces;

  SheetModel copyWith({
    String? id,
    double? width,
    double? height,
    List<LayoutPiece>? pieces,
  }) {
    return SheetModel(
      id: id ?? this.id,
      width: width ?? this.width,
      height: height ?? this.height,
      pieces: pieces ?? this.pieces,
    );
  }
}