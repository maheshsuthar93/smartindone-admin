enum GrainDirection {
  none,
  horizontal,
  vertical,
}