import 'package:flutter/material.dart';

import '../controllers/selection_controller.dart';

import 'package:flutter/material.dart';

import 'render_context.dart';
import 'renderer.dart';

class MarqueeRenderer implements Renderer {
  const MarqueeRenderer();

  @override
  void paint(RenderContext context) {
    final rect = context.controller.selection.marqueeRect;

    if (rect == null || rect.isEmpty) {
      return;
    }

    final zoom = context.controller.camera.zoom;

    final fillPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = context.theme.selectionColor.withOpacity(0.15);

    final borderPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5 / zoom
      ..color = context.theme.selectionColor;

    context.canvas.drawRect(rect, fillPaint);
    context.canvas.drawRect(rect, borderPaint);
  }
}
