import 'package:flutter/material.dart';

import '../controllers/selection_controller.dart';
import 'render_context.dart';
import 'renderer.dart';

class InteractionRenderer implements Renderer {
  const InteractionRenderer();

  @override
  void paint(RenderContext context) {
    final SelectionController selection = context.controller.selection;

    final Rect? marquee = selection.marqueeRect;

    if (marquee == null || marquee.isEmpty) {
      return;
    }

    final selectionColor = context.theme.selectionColor;
    final zoom = context.controller.camera.zoom;

    final fillPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = selectionColor.withOpacity(0.12);

    final borderPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5 / zoom
      ..color = selectionColor;

    context.canvas.drawRect(marquee, fillPaint);
    context.canvas.drawRect(marquee, borderPaint);
  }
}