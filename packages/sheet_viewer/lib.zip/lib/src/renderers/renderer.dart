import 'render_context.dart';

abstract interface class Renderer {
  void paint(RenderContext context);
}