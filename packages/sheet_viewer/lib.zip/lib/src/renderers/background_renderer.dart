import 'package:flutter/material.dart';

import 'render_context.dart';
import 'renderer.dart';

class BackgroundRenderer implements Renderer {
  const BackgroundRenderer();

  @override
  void paint(RenderContext context) {
    final canvas = context.canvas;
    final size = context.size;

    // Workspace background
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = const Color(0xFFF2F4F7),
    );

    // Dot grid
    final dotPaint = Paint()
      ..color = const Color(0xFFB0BEC5).withOpacity(.25);

    const spacing = 24.0;
    const radius = 1.0;

    for (double x = 0; x <= size.width; x += spacing) {
      for (double y = 0; y <= size.height; y += spacing) {
        canvas.drawCircle(
          Offset(x, y),
          radius,
          dotPaint,
        );
      }
    }
  }
}