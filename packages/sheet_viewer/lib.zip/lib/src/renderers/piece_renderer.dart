import 'package:flutter/material.dart';

import '../core/constants.dart';
import '../models/layout_piece.dart';
import '../theme/sheet_theme_data.dart';
import 'render_context.dart';
import 'renderer.dart';

class PieceRenderer implements Renderer {
  const PieceRenderer();

  @override
  void paint(RenderContext context) {
    final canvas = context.canvas;
    final theme = context.theme;

    for (final piece in context.controller.pieces) {
      _paintPiece(canvas: canvas, piece: piece, theme: theme, context: context);
    }
  }

  void _paintPiece({
    required Canvas canvas,
    required LayoutPiece piece,
    required SheetThemeData theme,
    required RenderContext context,
  }) {
    final b = piece.bounds;

    final rect = Rect.fromLTWH(b.x, b.y, b.width, b.height);

    final rRect = RRect.fromRectAndRadius(rect, SheetConstants.pieceRadius);

    // --------------------------------------------------------
    // Shadow
    // --------------------------------------------------------

    canvas.drawShadow(Path()..addRRect(rRect), Colors.black26, 2, false);

    // --------------------------------------------------------
    // Fill
    // --------------------------------------------------------

    final baseColor = theme.pieceColor(piece.status);

    final isHovered =
        context.controller.selection.hoveredPiece?.id == piece.id;

    final fillPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = isHovered
          ? Color.lerp(baseColor, Colors.white, 0.12)!
          : baseColor;

    canvas.drawRRect(rRect, fillPaint);

    // --------------------------------------------------------
    // Subtle highlight
    // --------------------------------------------------------

    canvas.drawRRect(
      rRect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0x22FFFFFF), Color(0x00000000)],
        ).createShader(rect),
    );

    // --------------------------------------------------------
    // Border
    // --------------------------------------------------------

    canvas.drawRRect(
      rRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = theme.pieceBorderColor,
    );
  }
}
