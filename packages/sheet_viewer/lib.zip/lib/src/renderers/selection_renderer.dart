import 'package:flutter/material.dart';

import 'render_context.dart';
import 'renderer.dart';

class SelectionRenderer implements Renderer {
  const SelectionRenderer();

  static const double _handleRadius = 5;

  @override
  void paint(RenderContext context) {
    final canvas = context.canvas;
    final controller = context.controller;
    final selection = controller.selection;

    final selectionColor = context.theme.selectionColor;
    final hoverColor = selectionColor.withOpacity(0.35);

    final zoom = controller.camera.zoom;

    final borderPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2 / zoom
      ..color = selectionColor;

    final hoverPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5 / zoom
      ..color = hoverColor;

    for (final piece in controller.pieces) {
      final rect = Rect.fromLTWH(
        piece.bounds.x,
        piece.bounds.y,
        piece.bounds.width,
        piece.bounds.height,
      );

      if (selection.hoveredPiece?.id == piece.id &&
          !selection.isSelected(piece.id)) {
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            rect.inflate(2 / zoom),
            Radius.circular(6 / zoom),
          ),
          hoverPaint,
        );
      }

      if (!selection.isSelected(piece.id)) {
        continue;
      }

      canvas.drawRRect(
        RRect.fromRectAndRadius(
          rect.inflate(2 / zoom),
          Radius.circular(6 / zoom),
        ),
        borderPaint,
      );

      _drawHandle(
        canvas,
        rect.topLeft,
        selectionColor,
        zoom,
      );

      _drawHandle(
        canvas,
        rect.topCenter,
        selectionColor,
        zoom,
      );

      _drawHandle(
        canvas,
        rect.topRight,
        selectionColor,
        zoom,
      );

      _drawHandle(
        canvas,
        rect.centerLeft,
        selectionColor,
        zoom,
      );

      _drawHandle(
        canvas,
        rect.centerRight,
        selectionColor,
        zoom,
      );

      _drawHandle(
        canvas,
        rect.bottomLeft,
        selectionColor,
        zoom,
      );

      _drawHandle(
        canvas,
        rect.bottomCenter,
        selectionColor,
        zoom,
      );

      _drawHandle(
        canvas,
        rect.bottomRight,
        selectionColor,
        zoom,
      );
    }
  }

  void _drawHandle(
      Canvas canvas,
      Offset center,
      Color color,
      double zoom,
      ) {
    final radius = _handleRadius / zoom;

    canvas.drawCircle(
      center,
      radius,
      Paint()..color = Colors.white,
    );

    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2 / zoom
        ..color = color,
    );
  }
}