import 'package:flutter/material.dart';

import '../controllers/sheet_viewer_controller.dart';
import '../theme/sheet_theme_data.dart';

class RenderContext {
  const RenderContext({
    required this.canvas,
    required this.size,
    required this.controller,
    required this.theme,
  });

  final Canvas canvas;
  final Size size;
  final SheetViewerController controller;
  final SheetThemeData theme;
}