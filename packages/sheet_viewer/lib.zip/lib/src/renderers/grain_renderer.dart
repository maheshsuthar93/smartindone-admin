import 'package:flutter/material.dart';

import '../models/grain_direction.dart';
import 'render_context.dart';
import 'renderer.dart';

class GrainRenderer implements Renderer {
  const GrainRenderer();

  @override
  void paint(RenderContext context) {
    final canvas = context.canvas;

    final paint = Paint()
      ..strokeWidth = 2
      ..color = Colors.black54;

    for (final piece in context.controller.pieces) {
      if (piece.grainDirection == GrainDirection.none) {
        continue;
      }

      final rect = Rect.fromLTWH(
        piece.bounds.x,
        piece.bounds.y,
        piece.bounds.width,
        piece.bounds.height,
      );

      if (piece.grainDirection == GrainDirection.horizontal) {
        final y = rect.center.dy;

        canvas.drawLine(
          Offset(rect.left + 8, y),
          Offset(rect.right - 14, y),
          paint,
        );

        canvas.drawLine(
          Offset(rect.right - 14, y),
          Offset(rect.right - 20, y - 5),
          paint,
        );

        canvas.drawLine(
          Offset(rect.right - 14, y),
          Offset(rect.right - 20, y + 5),
          paint,
        );
      } else {
        final x = rect.center.dx;

        canvas.drawLine(
          Offset(x, rect.top + 8),
          Offset(x, rect.bottom - 14),
          paint,
        );

        canvas.drawLine(
          Offset(x, rect.bottom - 14),
          Offset(x - 5, rect.bottom - 20),
          paint,
        );

        canvas.drawLine(
          Offset(x, rect.bottom - 14),
          Offset(x + 5, rect.bottom - 20),
          paint,
        );
      }
    }
  }
}