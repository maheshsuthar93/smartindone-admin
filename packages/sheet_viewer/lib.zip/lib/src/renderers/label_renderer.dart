import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/layout_piece.dart';
import '../theme/sheet_theme_data.dart';
import 'render_context.dart';
import 'renderer.dart';

class LabelRenderer implements Renderer {
  const LabelRenderer();

  @override
  void paint(RenderContext context) {
    final canvas = context.canvas;

    for (final piece in context.controller.pieces) {
      _paintPieceLabel(
        canvas,
        piece,
        context.theme,
      );
    }
  }

  void _paintPieceLabel(
      Canvas canvas,
      LayoutPiece piece,
      SheetThemeData theme,
      ) {
    final rect = Rect.fromLTWH(
      piece.bounds.x,
      piece.bounds.y,
      piece.bounds.width,
      piece.bounds.height,
    );

    // Don't render labels on tiny pieces.
    if (rect.width < 50 || rect.height < 35) {
      return;
    }

    final titleSize = math.min(
      rect.width / 9,
      rect.height / 5,
    ).clamp(10.0, 18.0);

    final dimensionSize = (titleSize * .75).clamp(8.0, 14.0);

    final textPainter = TextPainter(
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    );

    final span = TextSpan(
      children: [
        TextSpan(
          text: '${piece.label}\n',
          style: TextStyle(
            fontSize: titleSize,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
        TextSpan(
          text:
          '${piece.bounds.width.toInt()} × ${piece.bounds.height.toInt()}',
          style: TextStyle(
            fontSize: dimensionSize,
            color: Colors.black54,
          ),
        ),
      ],
    );

    textPainter.text = span;
    textPainter.layout(maxWidth: rect.width - 12);

    textPainter.paint(
      canvas,
      Offset(
        rect.center.dx - textPainter.width / 2,
        rect.center.dy - textPainter.height / 2,
      ),
    );
  }
}