import 'render_context.dart';
import 'renderer.dart';
import 'marquee_renderer.dart';

class RenderPipeline {
  RenderPipeline({List<Renderer>? renderers}) : _renderers = renderers ?? [];

  final List<Renderer> _renderers;

  List<Renderer> get renderers => _renderers;

  void add(Renderer renderer) {
    _renderers.add(renderer);
  }

  void paint(RenderContext context) {
    for (final renderer in _renderers) {
      renderer.paint(context);
    }
  }
}
