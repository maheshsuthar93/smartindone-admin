import 'package:flutter/material.dart';

import 'render_context.dart';
import 'renderer.dart';

/// Renders temporary interaction overlays.
///
/// V1
/// - Marquee selection
///
/// Future
/// - Snap guides
/// - Alignment guides
/// - Drop preview
/// - Measurement overlay
/// - Rotation guides
class OverlayRenderer implements Renderer {
  const OverlayRenderer();

  @override
  void paint(RenderContext context) {
    // Nothing to render yet.
    //
    // Batch 2 will render the marquee rectangle here.
  }
}