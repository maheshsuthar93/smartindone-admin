import 'package:flutter/material.dart';

import '../core/constants.dart';
import 'render_context.dart';
import 'renderer.dart';

class GridRenderer implements Renderer {
  const GridRenderer();

  @override
  void paint(RenderContext context) {
    final canvas = context.canvas;
    final sheet = context.controller.sheet;
    final theme = context.theme;

    final minorPaint = Paint()
      ..color = theme.gridColor.withValues(alpha: 0.30)
      ..strokeWidth = .5;

    final majorPaint = Paint()
      ..color = theme.gridColor.withValues(alpha: 0.60)
      ..strokeWidth = 1;

    const minorSpacing = 100.0;
    const majorSpacing = 500.0;

    for (double x = 0; x <= sheet.width; x += minorSpacing) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, sheet.height),
        (x % majorSpacing == 0) ? majorPaint : minorPaint,
      );
    }

    for (double y = 0; y <= sheet.height; y += minorSpacing) {
      canvas.drawLine(
        Offset(0, y),
        Offset(sheet.width, y),
        (y % majorSpacing == 0) ? majorPaint : minorPaint,
      );
    }
  }
}