import 'package:flutter/material.dart';

import '../models/edge_band.dart';
import 'render_context.dart';
import 'renderer.dart';

class EdgeBandRenderer implements Renderer {
  const EdgeBandRenderer();

  @override
  void paint(RenderContext context) {
    final canvas = context.canvas;

    final paint = Paint()
      ..color = context.theme.edgeBandColor
      ..strokeWidth = context.theme.edgeBandThickness
      ..strokeCap = StrokeCap.round;

    for (final piece in context.controller.pieces) {
      if (piece.edgeBands.isEmpty) continue;

      final r = Rect.fromLTWH(
        piece.bounds.x,
        piece.bounds.y,
        piece.bounds.width,
        piece.bounds.height,
      );

      if (piece.edgeBands.contains(EdgeBand.top)) {
        canvas.drawLine(r.topLeft, r.topRight, paint);
      }

      if (piece.edgeBands.contains(EdgeBand.bottom)) {
        canvas.drawLine(r.bottomLeft, r.bottomRight, paint);
      }

      if (piece.edgeBands.contains(EdgeBand.left)) {
        canvas.drawLine(r.topLeft, r.bottomLeft, paint);
      }

      if (piece.edgeBands.contains(EdgeBand.right)) {
        canvas.drawLine(r.topRight, r.bottomRight, paint);
      }
    }
  }
}