import 'package:flutter/material.dart';

import 'render_context.dart';
import 'renderer.dart';

class SheetRenderer implements Renderer {
  const SheetRenderer();

  @override
  void paint(RenderContext context) {
    final canvas = context.canvas;
    final sheet = context.controller.sheet;

    final rect = Rect.fromLTWH(0, 0, sheet.width, sheet.height);

    final rrect = RRect.fromRectAndRadius(rect, const Radius.circular(8));

    canvas.drawShadow(Path()..addRRect(rrect), Colors.black26, 8, false);

    canvas.drawRRect(rrect, Paint()..color = Colors.white);

    canvas.drawRRect(
      rrect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..color = Colors.grey.shade500,
    );
  }
}
