import 'dart:ui';

import 'package:flutter/foundation.dart';

import '../commands/command.dart';
import '../commands/command_history.dart';
import '../models/layout_piece.dart';
import '../models/sheet_model.dart';
import 'camera_controller.dart';
import 'selection_controller.dart';

class SheetViewerController extends ChangeNotifier {
  SheetViewerController({
    required SheetModel sheet,
    CameraController? camera,
    SelectionController? selection,
  }) : _sheet = sheet,
       camera = camera ?? CameraController(),
       selection = selection ?? SelectionController() {
    this.camera.addListener(notifyListeners);
    this.selection.addListener(notifyListeners);
  }

  SheetModel _sheet;

  final CameraController camera;

  final SelectionController selection;

  final CommandHistory _history = CommandHistory();

  SheetModel get sheet => _sheet;

  List<LayoutPiece> get pieces => _sheet.pieces;

  bool get canUndo => _history.canUndo;

  bool get canRedo => _history.canRedo;

  //--------------------------------------------------------------------------
  // Command API
  //--------------------------------------------------------------------------

  void execute(Command command) {
    _history.execute(command);
  }

  void undo() {
    if (!_history.canUndo) return;

    _history.undo();
  }

  void redo() {
    if (!_history.canRedo) return;

    _history.redo();
  }

  void clearHistory() {
    _history.clear();
  }

  //--------------------------------------------------------------------------
  // Sheet
  //--------------------------------------------------------------------------

  void updateSheet(SheetModel sheet) {
    _sheet = sheet;
    notifyListeners();
  }

  LayoutPiece? pieceById(String id) {
    try {
      return _sheet.pieces.firstWhere((p) => p.id == id);
    } catch (_) {
      return null;
    }
  }

  //--------------------------------------------------------------------------
  // Single piece update
  //--------------------------------------------------------------------------

  void updatePiece(LayoutPiece piece) {
    final index = _sheet.pieces.indexWhere((p) => p.id == piece.id);

    if (index == -1) return;

    final pieces = List<LayoutPiece>.from(_sheet.pieces);
    pieces[index] = piece;

    _sheet = _sheet.copyWith(pieces: pieces);

    notifyListeners();
  }

  //--------------------------------------------------------------------------
  // Multiple piece update
  //--------------------------------------------------------------------------

  void updatePieces(Iterable<LayoutPiece> updatedPieces) {
    final updates = <String, LayoutPiece>{
      for (final piece in updatedPieces) piece.id: piece,
    };

    if (updates.isEmpty) {
      return;
    }

    bool changed = false;

    final pieces = _sheet.pieces
        .map((piece) {
          final updated = updates[piece.id];

          if (updated == null) {
            return piece;
          }

          changed = true;
          return updated;
        })
        .toList(growable: false);

    if (!changed) {
      return;
    }

    _sheet = _sheet.copyWith(pieces: pieces);

    notifyListeners();
  }

  //--------------------------------------------------------------------------
  // Add / Remove
  //--------------------------------------------------------------------------

  void addPiece(LayoutPiece piece) {
    _sheet = _sheet.copyWith(pieces: [..._sheet.pieces, piece]);

    notifyListeners();
  }

  void removePiece(String id) {
    _sheet = _sheet.copyWith(
      pieces: _sheet.pieces.where((e) => e.id != id).toList(),
    );

    selection.clear();

    notifyListeners();
  }

  //--------------------------------------------------------------------------
  // Move
  //--------------------------------------------------------------------------

  void movePiece(String id, Offset delta) {
    final piece = pieceById(id);

    if (piece == null) return;

    updatePiece(
      piece.copyWith(
        bounds: piece.bounds.copyWith(
          x: piece.bounds.x + delta.dx,
          y: piece.bounds.y + delta.dy,
        ),
      ),
    );
  }

  void pushCommand(Command command) {
    _history.push(command);
  }
}
