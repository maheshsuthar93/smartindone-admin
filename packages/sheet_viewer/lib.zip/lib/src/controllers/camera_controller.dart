import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../core/constants.dart';
import '../models/sheet_model.dart';

class CameraController extends ChangeNotifier {
  Offset _offset = Offset.zero;
  double _zoom = SheetConstants.defaultZoom;

  Size _viewport = Size.zero;

  Offset get offset => _offset;
  double get zoom => _zoom;
  Size get viewport => _viewport;

  Matrix4 get transform => Matrix4.identity()
    ..translate(_offset.dx, _offset.dy)
    ..scale(_zoom);

  /// Converts world coordinates into screen coordinates.
  Offset worldToScreen(Offset world) {
    return Offset(
      world.dx * _zoom + _offset.dx,
      world.dy * _zoom + _offset.dy,
    );
  }

  /// Converts screen coordinates into world coordinates.
  Offset screenToWorld(Offset screen) {
    return Offset(
      (screen.dx - _offset.dx) / _zoom,
      (screen.dy - _offset.dy) / _zoom,
    );
  }

  void updateViewport(Size size) {
    if (_viewport == size) return;
    _viewport = size;
  }

  void pan(Offset delta) {
    _offset += delta;
    notifyListeners();
  }

  void setOffset(Offset value) {
    if (_offset == value) return;
    _offset = value;
    notifyListeners();
  }

  void zoomTo(double value) {
    final clamped = value.clamp(
      SheetConstants.minZoom,
      SheetConstants.maxZoom,
    );

    if (clamped == _zoom) return;

    _zoom = clamped;
    notifyListeners();
  }

  void zoomBy(double factor) {
    zoomTo(_zoom * factor);
  }

  void centerOn(Offset worldPoint) {
    if (_viewport == Size.zero) return;

    _offset = Offset(
      _viewport.width / 2 - worldPoint.dx * _zoom,
      _viewport.height / 2 - worldPoint.dy * _zoom,
    );

    notifyListeners();
  }

  void fitToSheet(
      SheetModel sheet, {
        double padding = 48,
      }) {
    if (_viewport == Size.zero) return;

    final scaleX =
        (_viewport.width - padding * 2) / sheet.width;

    final scaleY =
        (_viewport.height - padding * 2) / sheet.height;

    _zoom = math.min(scaleX, scaleY).clamp(
      SheetConstants.minZoom,
      SheetConstants.maxZoom,
    );

    final scaledWidth = sheet.width * _zoom;
    final scaledHeight = sheet.height * _zoom;

    _offset = Offset(
      (_viewport.width - scaledWidth) / 2,
      (_viewport.height - scaledHeight) / 2,
    );

    notifyListeners();
  }

  void reset() {
    _offset = Offset.zero;
    _zoom = SheetConstants.defaultZoom;
    notifyListeners();
  }
  void zoomAt({
    required Offset screenPosition,
    required double scale,
  }) {
    final before = screenToWorld(screenPosition);

    zoomTo(_zoom * scale);

    final after = screenToWorld(screenPosition);

    _offset += (after - before) * _zoom;

    notifyListeners();
  }
}