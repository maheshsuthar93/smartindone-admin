import 'dart:ui';

import 'package:flutter/foundation.dart';

import '../../sheet_viewer.dart';

class SelectionController extends ChangeNotifier {
  final Set<String> _selectedIds = {};

  LayoutPiece? _hoveredPiece;

  String? _draggingPieceId;

  Rect? _marqueeRect;

  Set<String> get selectedIds => Set.unmodifiable(_selectedIds);

  List<String> get selectedList => _selectedIds.toList(growable: false);

  LayoutPiece? get hoveredPiece => _hoveredPiece;

  String? get draggingPieceId => _draggingPieceId;

  Rect? get marqueeRect => _marqueeRect;

  bool get hasSelection => _selectedIds.isNotEmpty;

  bool get isDragging => _draggingPieceId != null;

  bool get isMarqueeSelecting => _marqueeRect != null;

  int get selectionCount => _selectedIds.length;

  //--------------------------------------------------------------------------
  // Hover
  //--------------------------------------------------------------------------

  void setHovered(LayoutPiece? piece) {
    if (_hoveredPiece?.id == piece?.id) return;

    _hoveredPiece = piece;
    notifyListeners();
  }

  //--------------------------------------------------------------------------
  // Selection
  //--------------------------------------------------------------------------

  bool isSelected(String id) {
    return _selectedIds.contains(id);
  }

  bool containsOnly(String id) {
    return _selectedIds.length == 1 && _selectedIds.contains(id);
  }

  void select(String id) {
    if (_selectedIds.length == 1 && _selectedIds.contains(id)) {
      return;
    }

    _selectedIds
      ..clear()
      ..add(id);

    notifyListeners();
  }

  void selectAll(Iterable<String> ids) {
    _selectedIds
      ..clear()
      ..addAll(ids);

    notifyListeners();
  }

  void add(String id) {
    if (_selectedIds.add(id)) {
      notifyListeners();
    }
  }

  void remove(String id) {
    if (_selectedIds.remove(id)) {
      notifyListeners();
    }
  }

  void toggle(String id) {
    if (_selectedIds.remove(id)) {
      notifyListeners();
      return;
    }

    _selectedIds.add(id);
    notifyListeners();
  }

  void clear() {
    if (_selectedIds.isEmpty && _marqueeRect == null) {
      return;
    }

    _selectedIds.clear();
    _marqueeRect = null;

    notifyListeners();
  }

  //--------------------------------------------------------------------------
  // Drag
  //--------------------------------------------------------------------------

  void startDragging(String id) {
    if (_draggingPieceId == id) return;

    _draggingPieceId = id;
    notifyListeners();
  }

  void stopDragging() {
    if (_draggingPieceId == null) return;

    _draggingPieceId = null;
    notifyListeners();
  }

  //--------------------------------------------------------------------------
  // Marquee Selection
  //--------------------------------------------------------------------------

  void startMarquee(Offset worldPosition) {
    _marqueeRect = Rect.fromLTWH(
      worldPosition.dx,
      worldPosition.dy,
      0,
      0,
    );

    notifyListeners();
  }

  void updateMarquee(Offset start, Offset current) {
    _marqueeRect = Rect.fromPoints(start, current);

    notifyListeners();
  }

  void finishMarquee() {
    if (_marqueeRect == null) return;

    _marqueeRect = null;
    notifyListeners();
  }

  void cancelMarquee() {
    finishMarquee();
  }
}