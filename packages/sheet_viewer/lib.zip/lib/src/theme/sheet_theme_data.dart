import 'package:flutter/material.dart';

import '../models/piece_status.dart';

@immutable
class SheetThemeData {
  const SheetThemeData({
    this.sheetColor = Colors.white,
    this.sheetBorderColor = const Color(0xFFBDBDBD),
    this.selectionColor = Colors.blue,
    this.pieceBorderColor = const Color(0xFF424242),
    this.gridColor = const Color(0xFFE0E0E0),
    this.textStyle = const TextStyle(fontSize: 12, color: Colors.black87),
    this.edgeBandColor = const Color(0xFF424242),
    this.edgeBandThickness = 4,
    this.titleStyle = const TextStyle(
      fontSize: 14,
      fontWeight: FontWeight.w600,
    ),

    this.subtitleStyle = const TextStyle(fontSize: 11, color: Colors.black54),
  });

  final Color sheetColor;
  final Color sheetBorderColor;
  final Color selectionColor;
  final Color pieceBorderColor;
  final Color gridColor;
  final TextStyle textStyle;
  final Color edgeBandColor;
  final double edgeBandThickness;
  final TextStyle titleStyle;
  final TextStyle subtitleStyle;

  Color pieceColor(PieceStatus status) {
    switch (status) {
      case PieceStatus.pending:
        return const Color(0xFFF5F5F5);

      case PieceStatus.inProgress:
        return const Color(0xFFFFF59D);

      case PieceStatus.completed:
        return const Color(0xFFC8E6C9);

      case PieceStatus.rejected:
        return const Color(0xFFFFCDD2);
    }
  }
}
