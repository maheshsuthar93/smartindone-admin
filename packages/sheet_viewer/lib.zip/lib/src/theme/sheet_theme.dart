import 'package:flutter/widgets.dart';

import 'sheet_theme_data.dart';

class SheetTheme extends InheritedWidget {
  const SheetTheme({
    super.key,
    required this.data,
    required super.child,
  });

  final SheetThemeData data;

  static SheetThemeData of(BuildContext context) {
    final theme =
    context.dependOnInheritedWidgetOfExactType<SheetTheme>();

    return theme?.data ?? const SheetThemeData();
  }

  @override
  bool updateShouldNotify(SheetTheme oldWidget) {
    return oldWidget.data != data;
  }
}