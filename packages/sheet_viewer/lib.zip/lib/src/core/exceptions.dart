/// Base package exception.
class SheetViewerException implements Exception {
  const SheetViewerException(this.message);

  final String message;

  @override
  String toString() => 'SheetViewerException: $message';
}

/// Invalid sheet.
class InvalidSheetException extends SheetViewerException {
  const InvalidSheetException(super.message);
}

/// Invalid piece.
class InvalidPieceException extends SheetViewerException {
  const InvalidPieceException(super.message);
}