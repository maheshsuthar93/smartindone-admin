import 'package:flutter/material.dart';

/// Package wide constants.
abstract final class SheetConstants {
  const SheetConstants._();

  /// Default zoom level.
  static const double defaultZoom = 1.0;

  /// Minimum allowed zoom.
  static const double minZoom = 0.2;

  /// Maximum allowed zoom.
  static const double maxZoom = 8.0;

  /// Default grid spacing in millimeters.
  static const double gridSize = 100.0;

  /// Default selection stroke width.
  static const double selectionStrokeWidth = 2.0;

  /// Default piece border width.
  static const double pieceBorderWidth = 1.0;

  /// Default corner radius.
  static const Radius pieceRadius = Radius.circular(4);
}
