/// Represents either a successful value or an error.
sealed class Result<T> {
  const Result();

  bool get isSuccess;

  bool get isFailure => !isSuccess;
}

final class Success<T> extends Result<T> {
  const Success(this.value);

  final T value;

  @override
  bool get isSuccess => true;
}

final class Failure<T> extends Result<T> {
  const Failure(this.message);

  final String message;

  @override
  bool get isSuccess => false;
}