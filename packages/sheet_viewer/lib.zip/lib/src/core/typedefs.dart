import 'package:flutter/foundation.dart';

/// Generic callback.
typedef VoidCallback0 = VoidCallback;

/// Generic value changed callback.
typedef ValueChanged0<T> = void Function(T value);

/// Predicate.
typedef Predicate<T> = bool Function(T value);

/// Comparator.
typedef Compare<T> = int Function(T a, T b);