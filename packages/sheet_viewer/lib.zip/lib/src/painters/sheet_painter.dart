import 'package:flutter/material.dart';

import '../controllers/sheet_viewer_controller.dart';
import '../renderers/render_context.dart';
import '../renderers/render_pipeline.dart';
import '../theme/sheet_theme_data.dart';

class SheetPainter extends CustomPainter {
  SheetPainter({
    required this.controller,
    required this.pipeline,
    required this.theme,
  }) : super(repaint: controller);

  final SheetViewerController controller;
  final RenderPipeline pipeline;
  final SheetThemeData theme;

  @override
  void paint(Canvas canvas, Size size) {
    final camera = controller.camera;

    canvas.save();

    // Apply camera transform
    canvas.translate(
      camera.offset.dx,
      camera.offset.dy,
    );

    canvas.scale(camera.zoom);

    // Render everything through the pipeline
    pipeline.paint(
      RenderContext(
        canvas: canvas,
        size: size,
        controller: controller,
        theme: theme,
      ),
    );

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant SheetPainter oldDelegate) {
    return oldDelegate.controller != controller ||
        oldDelegate.pipeline != pipeline ||
        oldDelegate.theme != theme;
  }
}