import 'package:flutter/material.dart';

import '../controllers/sheet_viewer_controller.dart';
import '../renderers/background_renderer.dart';
import '../renderers/edge_band_renderer.dart';
import '../renderers/grain_renderer.dart';
import '../renderers/grid_renderer.dart';
import '../renderers/label_renderer.dart';
import '../renderers/marquee_renderer.dart';
import '../renderers/overlay_renderer.dart';
import '../renderers/piece_renderer.dart';
import '../renderers/render_pipeline.dart';
import '../renderers/selection_renderer.dart';
import '../renderers/sheet_renderer.dart';
import '../theme/sheet_theme.dart';
import '../theme/sheet_theme_data.dart';
import 'gesture_layer.dart';
import 'sheet_canvas.dart';

class InteractiveSheet extends StatefulWidget {
  const InteractiveSheet({
    super.key,
    required this.controller,
    this.theme = const SheetThemeData(),
  });

  final SheetViewerController controller;
  final SheetThemeData theme;

  @override
  State<InteractiveSheet> createState() => _InteractiveSheetState();
}

class _InteractiveSheetState extends State<InteractiveSheet> {
  late final RenderPipeline _pipeline;

  bool _initialized = false;

  @override
  void initState() {
    super.initState();

    _pipeline = RenderPipeline(
      renderers: [
        BackgroundRenderer(),
        GridRenderer(),
        PieceRenderer(),
        GrainRenderer(),
        LabelRenderer(),
        SelectionRenderer(),

        MarqueeRenderer(), // <-- Add here

        OverlayRenderer(),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_initialized) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;

        widget.controller.camera.fitToSheet(widget.controller.sheet);

        _initialized = true;
      });
    }

    return SheetTheme(
      data: widget.theme,
      child: GestureLayer(
        controller: widget.controller,
        child: RepaintBoundary(
          child: SheetCanvas(
            controller: widget.controller,
            pipeline: _pipeline,
          ),
        ),
      ),
    );
  }
}
