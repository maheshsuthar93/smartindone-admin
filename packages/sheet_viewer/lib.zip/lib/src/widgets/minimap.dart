import 'package:flutter/material.dart';

class Minimap extends StatelessWidget {
  const Minimap({super.key});

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink();
  }
}