import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../../sheet_viewer.dart';
import '../interactions/interaction_manager.dart';
import '../interactions/interaction_mode.dart';

class GestureLayer extends StatefulWidget {
  const GestureLayer({
    super.key,
    required this.controller,
    required this.child,
  });

  final SheetViewerController controller;
  final Widget child;

  @override
  State<GestureLayer> createState() => _GestureLayerState();
}

class _GestureLayerState extends State<GestureLayer> {
  late final InteractionManager _interaction;

  Offset? _lastPanPosition;

  @override
  void initState() {
    super.initState();

    _interaction = InteractionManager(controller: widget.controller);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (_, __) {
        return MouseRegion(
          cursor: _mouseCursor(),

          onHover: (event) {
            _interaction.hover(event.localPosition);
          },

          child: Listener(
            onPointerSignal: (event) {
              if (event is PointerScrollEvent) {
                widget.controller.camera.zoomAt(
                  screenPosition: event.localPosition,
                  scale: event.scrollDelta.dy > 0 ? 0.9 : 1.1,
                );
              }
            },

            child: GestureDetector(
              behavior: HitTestBehavior.opaque,

              onTapUp: (details) {
                _interaction.tap(details.localPosition);
              },

              onPanStart: (details) {
                _lastPanPosition = details.localPosition;

                _interaction.startDrag(details.localPosition);
              },

              onPanUpdate: (details) {
                switch (_interaction.mode) {
                  case InteractionMode.dragging:
                  case InteractionMode.resizing:
                    _interaction.updateDrag(details.localPosition);
                    break;

                  case InteractionMode.panning:
                    if (_lastPanPosition != null) {
                      widget.controller.camera.pan(
                        details.localPosition - _lastPanPosition!,
                      );

                      _lastPanPosition = details.localPosition;
                    }
                    break;

                  case InteractionMode.idle:
                    break;
                  case InteractionMode.marqueeSelecting:
                    // TODO: Handle this case.
                    throw UnimplementedError();
                }
              },

              onPanEnd: (_) {
                _lastPanPosition = null;

                _interaction.endDrag();
              },

              onPanCancel: () {
                _lastPanPosition = null;

                _interaction.cancel();
              },

              child: widget.child,
            ),
          ),
        );
      },
    );
  }

  MouseCursor _mouseCursor() {
    switch (_interaction.mode) {
      case InteractionMode.dragging:
        return SystemMouseCursors.grabbing;

      case InteractionMode.resizing:
        return SystemMouseCursors.precise;

      case InteractionMode.panning:
        return SystemMouseCursors.move;

      case InteractionMode.idle:
        return SystemMouseCursors.grab;
      case InteractionMode.marqueeSelecting:
        // TODO: Handle this case.
        throw UnimplementedError();
    }
  }
}
