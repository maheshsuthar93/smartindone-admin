import 'package:flutter/material.dart';

class SheetToolbar extends StatelessWidget {
  const SheetToolbar({super.key});

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink();
  }
}