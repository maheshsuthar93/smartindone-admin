import 'package:flutter/material.dart';

import '../controllers/sheet_viewer_controller.dart';
import '../painters/sheet_painter.dart';
import '../renderers/render_pipeline.dart';
import '../theme/sheet_theme.dart';

class SheetCanvas extends StatelessWidget {
  const SheetCanvas({
    super.key,
    required this.controller,
    required this.pipeline,
  });

  final SheetViewerController controller;
  final RenderPipeline pipeline;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        controller.camera.updateViewport(
          Size(
            constraints.maxWidth,
            constraints.maxHeight,
          ),
        );

        return ClipRect(
          child: RepaintBoundary(
            child: CustomPaint(
              isComplex: true,
              willChange: true,
              painter: SheetPainter(
                controller: controller,
                pipeline: pipeline,
                theme: SheetTheme.of(context),
              ),
              child: const SizedBox.expand(),
            ),
          ),
        );
      },
    );
  }
}