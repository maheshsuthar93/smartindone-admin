import 'package:flutter/material.dart';

import '../../sheet_viewer.dart';
import '../callbacks/sheet_viewer_callbacks.dart';
import '../events/piece_interaction_event.dart';
import '../theme/sheet_viewer_theme.dart';
import '../theme/sheet_viewer_theme_data.dart';

class SheetViewer extends StatelessWidget {
  const SheetViewer({
    super.key,
    required this.controller,
    this.theme = const SheetViewerThemeData(),
    this.callbacks = SheetViewerCallbacks.empty,
  });

  final SheetViewerController controller;

  final SheetViewerThemeData theme;

  final SheetViewerCallbacks callbacks;

  @override
  Widget build(BuildContext context) {
    return SheetViewerTheme(
      data: theme,
      child: SheetView(controller: controller, callbacks: callbacks),
    );
  }
}
