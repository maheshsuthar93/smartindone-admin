import 'package:flutter/material.dart';

import '../../sheet_viewer.dart';

class SheetViewerToolbar extends StatelessWidget {
  const SheetViewerToolbar({super.key, required this.controller});

  final SheetViewerController controller;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      elevation: 1,
      color: theme.colorScheme.surface,
      child: SizedBox(
        height: 56,
        child: AnimatedBuilder(
          animation: controller,
          builder: (_, __) {
            final current = controller.currentSheetIndex + 1;
            final total = controller.layout.sheets.length;
            final zoom = (controller.scale * 100).round();

            return Row(
              children: [
                const SizedBox(width: 16),

                Text(
                  'Sheet $current of $total',
                  style: theme.textTheme.titleMedium,
                ),

                const SizedBox(width: 20),

                IconButton(
                  tooltip: 'Previous Sheet',
                  onPressed: current > 1 ? controller.previousSheet : null,
                  icon: const Icon(Icons.chevron_left),
                ),

                IconButton(
                  tooltip: 'Next Sheet',
                  onPressed: current < total ? controller.nextSheet : null,
                  icon: const Icon(Icons.chevron_right),
                ),

                const VerticalDivider(),

                IconButton(
                  tooltip: 'Zoom In',
                  onPressed: controller.zoomIn,
                  icon: const Icon(Icons.add),
                ),

                IconButton(
                  tooltip: 'Zoom Out',
                  onPressed: controller.zoomOut,
                  icon: const Icon(Icons.remove),
                ),

                TextButton.icon(
                  onPressed: controller.fitToScreen,
                  icon: const Icon(Icons.fit_screen),
                  label: const Text('Fit'),
                ),

                const SizedBox(width: 16),

                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text('$zoom%', style: theme.textTheme.labelLarge),
                ),

                const Spacer(),

                OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.straighten),
                  label: const Text('Actual Size'),
                ),

                const SizedBox(width: 16),
              ],
            );
          },
        ),
      ),
    );
  }
}
