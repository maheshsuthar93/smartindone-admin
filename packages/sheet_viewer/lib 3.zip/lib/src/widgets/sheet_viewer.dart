import 'package:flutter/material.dart';
import 'package:sheet_viewer/src/widgets/sheet_viewer_toolbar.dart';

import '../../sheet_viewer.dart';
import '../theme/sheet_viewer_theme.dart';
import 'viewer_card.dart';

// class SheetViewer extends StatelessWidget {
//   const SheetViewer({
//     super.key,
//     required this.controller,
//     this.theme = const SheetViewerThemeData(),
//     this.callbacks = SheetViewerCallbacks.empty,
//     this.showToolbar = true,
//   });
//
//   final SheetViewerController controller;
//
//   final SheetViewerThemeData theme;
//
//   final SheetViewerCallbacks callbacks;
//   final bool showToolbar;
//
//   @override
//   Widget build(BuildContext context) {
//     return SheetViewerTheme(
//       data: theme,
//       child: Column(
//         children: [
//           if (showToolbar) ViewerToolbar(controller: controller),
//
//           Expanded(
//             child: SheetView(controller: controller, callbacks: callbacks),
//           ),
//         ],
//       ),
//     );
//   }
// }
class SheetViewer extends StatelessWidget {
  const SheetViewer({
    super.key,
    required this.controller,
    this.theme = const SheetViewerThemeData(),
    this.callbacks = SheetViewerCallbacks.empty,
    this.showToolbar = true,
  });

  final SheetViewerController controller;
  final SheetViewerThemeData theme;
  final SheetViewerCallbacks callbacks;

  /// Shows the top toolbar.
  final bool showToolbar;

  @override
  Widget build(BuildContext context) {
    return SheetViewerTheme(
      data: theme,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            if (showToolbar)
              ViewerCard(child: SheetViewerToolbar(controller: controller)),

            if (showToolbar) const SizedBox(height: 12),

            Expanded(
              child: ViewerCard(
                child: SheetView(controller: controller, callbacks: callbacks),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
