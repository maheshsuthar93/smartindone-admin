import 'package:flutter/material.dart';

import '../../../sheet_viewer.dart';
import '../../models/label_mode.dart';
import '../layout/piece_info_layout.dart';
import '../render_context.dart';
import '../render_scene.dart';
import '../renderer.dart';
import 'package:characters/characters.dart';

final class LabelRenderer implements Renderer {
  const LabelRenderer();

  static const double _padding = 4;

  @override
  void paint(Canvas canvas, RenderContext context, RenderScene scene) {
    if (!context.theme.showLabels) {
      return;
    }

    for (final renderPiece in scene.pieces) {
      final rect = renderPiece.bounds.rect;

      final info = PieceInfoLayout.build(
        piece: renderPiece.piece,
        width: rect.width,
        height: rect.height,
      );

      if (info.isEmpty) {
        continue;
      }

      final painter = context.cache.text.painter(
        text: info.text,
        style: context.theme.labelStyle,
        textAlign: TextAlign.center,
        maxLines: info.lines.length,
      );

      final dx = rect.center.dx - painter.width / 2;
      final dy = rect.center.dy - painter.height / 2;

      painter.paint(canvas, Offset(dx, dy));
    }
  }

  String _label(Piece piece, LabelMode mode) {
    switch (mode) {
      case LabelMode.none:
        return '';

      case LabelMode.name:
        return piece.label;

      case LabelMode.nameAndSize:
        return '${piece.label}\n${piece.sizeLabel}';

      case LabelMode.full:
        return '${piece.label}\n${piece.sizeLabel}';
    }
  }

  String _buildLabel(Piece piece, Rect rect) {
    final minSide = rect.shortestSide;

    if (minSide < 20) {
      return '';
    }

    if (minSide < 40) {
      return piece.label.characters.first;
    }

    if (minSide < 80) {
      return piece.label;
    }

    return '${piece.label}\n${piece.sizeLabel}';
  }
}
