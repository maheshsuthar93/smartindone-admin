import 'package:flutter/foundation.dart';

import 'edge_side.dart';
import 'piece_bounds.dart';

@immutable
class Piece {
  const Piece({
    required this.id,
    required this.label,
    required this.bounds,
    required this.materialId,
    this.quantity = 1,
    this.rotation = PieceRotation.none,
    this.grainDirection = GrainDirection.none,
    this.edgeBands = const <EdgeSide>{},
    this.data,
    this.partNo,
    this.materialName,
    this.thickness,
    this.remarks,
  });

  final String? partNo;

  final String? materialName;

  final double? thickness;

  final String? remarks;
  final String id;

  final String label;

  final PieceBounds bounds;

  final String materialId;

  /// Number of identical parts represented by this piece.
  ///
  /// Defaults to 1.
  final int quantity;

  final PieceRotation rotation;

  final GrainDirection grainDirection;

  final Set<EdgeSide> edgeBands;

  final Object? data;

  bool hasEdgeBand(EdgeSide side) => edgeBands.contains(side);

  String get sizeLabel => '${bounds.width.toInt()} × ${bounds.height.toInt()}';

  Piece copyWith({
    String? id,
    String? label,
    PieceBounds? bounds,
    String? materialId,
    int? quantity,
    PieceRotation? rotation,
    GrainDirection? grainDirection,
    Set<EdgeSide>? edgeBands,
    Object? data = _sentinel,
  }) {
    return Piece(
      id: id ?? this.id,
      label: label ?? this.label,
      bounds: bounds ?? this.bounds,
      materialId: materialId ?? this.materialId,
      quantity: quantity ?? this.quantity,
      rotation: rotation ?? this.rotation,
      grainDirection: grainDirection ?? this.grainDirection,
      edgeBands: edgeBands ?? this.edgeBands,
      data: identical(data, _sentinel) ? this.data : data,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Piece &&
          id == other.id &&
          label == other.label &&
          bounds == other.bounds &&
          materialId == other.materialId &&
          quantity == other.quantity &&
          rotation == other.rotation &&
          grainDirection == other.grainDirection &&
          setEquals(edgeBands, other.edgeBands) &&
          data == other.data;

  @override
  int get hashCode => Object.hash(
    id,
    label,
    bounds,
    materialId,
    quantity,
    rotation,
    grainDirection,
    Object.hashAll(edgeBands),
    data,
  );
}
// @immutable
// class Piece {
//   const Piece({
//     required this.id,
//     required this.label,
//     required this.bounds,
//     required this.materialId,
//     this.rotation = PieceRotation.none,
//     this.grainDirection = GrainDirection.none,
//     this.edgeBands = const <EdgeSide>{},
//     this.data,
//   });
//
//   /// Unique identifier.
//   final String id;
//
//   /// Display name.
//   ///
//   /// Example:
//   /// "P1"
//   /// "Left Side"
//   /// "Drawer Front"
//   final String label;
//
//   /// Position and size on the sheet.
//   final PieceBounds bounds;
//
//   /// Material used by this piece.
//   final String materialId;
//
//   /// Piece rotation on the sheet.
//   final PieceRotation rotation;
//
//   /// Grain direction.
//   final GrainDirection grainDirection;
//
//   /// Edge-banded sides.
//   final Set<EdgeSide> edgeBands;
//
//   /// Optional application-specific object.
//   final Object? data;
//
//   Piece copyWith({
//     String? id,
//     String? label,
//     PieceBounds? bounds,
//     String? materialId,
//     PieceRotation? rotation,
//     GrainDirection? grainDirection,
//     Set<EdgeSide>? edgeBands,
//     Object? data = _sentinel,
//   }) {
//     return Piece(
//       id: id ?? this.id,
//       label: label ?? this.label,
//       bounds: bounds ?? this.bounds,
//       materialId: materialId ?? this.materialId,
//       rotation: rotation ?? this.rotation,
//       grainDirection: grainDirection ?? this.grainDirection,
//       edgeBands: edgeBands ?? this.edgeBands,
//       data: identical(data, _sentinel) ? this.data : data,
//     );
//   }
//
//   @override
//   bool operator ==(Object other) =>
//       identical(this, other) ||
//       other is Piece &&
//           id == other.id &&
//           label == other.label &&
//           bounds == other.bounds &&
//           materialId == other.materialId &&
//           rotation == other.rotation &&
//           grainDirection == other.grainDirection &&
//           setEquals(edgeBands, other.edgeBands) &&
//           data == other.data;
//
//   @override
//   int get hashCode => Object.hash(
//     id,
//     label,
//     bounds,
//     materialId,
//     rotation,
//     grainDirection,
//     Object.hashAll(edgeBands),
//     data,
//   );
//
//   String get sizeLabel => '${bounds.width.toInt()} × ${bounds.height.toInt()}';
//
//   bool hasEdgeBand(EdgeSide side) {
//     return edgeBands.contains(side);
//   }
// }

const _sentinel = Object();

enum PieceRotation { none, clockwise90, clockwise180, clockwise270 }

enum GrainDirection { none, horizontal, vertical }
